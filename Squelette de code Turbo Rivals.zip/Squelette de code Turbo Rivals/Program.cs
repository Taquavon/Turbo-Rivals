﻿using UnityEngine;

public class VehicleController : MonoBehaviour
{
    // Attributs
    public float speed = 10f;

    // Méthodes
    void Update()
    {
        // Logique de contrôle du véhicule
    }
}
